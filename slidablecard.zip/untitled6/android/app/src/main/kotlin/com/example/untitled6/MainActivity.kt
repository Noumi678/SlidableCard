package com.example.untitled6

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
